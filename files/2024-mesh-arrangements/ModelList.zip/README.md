# README

This is the supplementary material for "Exact and Efficient Intersection Resolution for Mesh Arrangements," including model lists of datasets used in the paper (Thingi10k.txt and stress-testing.txt).

## Thingi10k.txt

A list of models, the model can be download from [here](https://ten-thousand-models.appspot.com/).

## stress-testing.txt

A list of slightly rotated models.

The original model comes from `Thingi10.txt`. Each model has four transformation matrix. Apply these transformations to the model and merge the four results to produce the final model.
